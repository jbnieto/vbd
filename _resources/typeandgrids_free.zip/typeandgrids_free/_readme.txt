Type & Grids
www.typeandgrids.com

Hawthorne v1.1.0
Willamette v1.1.5


-----------------------------
GETTING STARTED GUIDE
-----------------------------
1) Begin by unzipping the zip file and moving the "Hawthorne" folder to a location on your computer where you want to store your site.

2) Inside the "Hawthorne" folder, open "index.html" with your web browser.
				
3) Next, open the same "index.html" file in your text editor. Locate the CSS link near the top of the page ("hawthorne_type2_color3.css").
				
4) Change the type and color themes by changing the number. For example, changing the "type2" part to "type3" will load type theme 3. There are 6 type themes and 6 color themes included (the Pro versions contain additional type and color themes). Save the page in your text editor and then refresh the page in your web browser to see the results.

5) Continue to scroll through "index.html" and edit the text to add your own content. Everything should be fairly intuitive and self-explanatory.


-----------------------------
SUPPORT
-----------------------------
There are lots of helpful tips in the FAQ here:
www.typeandgrids.com/support


-----------------------------
TERMS OF USE
-----------------------------
www.typeandgrids.com/terms


-----------------------------
PLEASE DON'T BE A PIRATE
-----------------------------
www.typeandgrids.com/pirates


Copyright 2014 Jeremiah Shoaf Design LLC. All rights reserved.